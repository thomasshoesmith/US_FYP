University Of Sussex
Informatics Final Year Project UG
Thomas Shoesmith
08/08/2022

There are 5 supporting files for the FYP: 
4 .py files to be ran though GeNN, 
1 .ipynb showcasing the development of the FP neuron


FP_SingleNeuron.py				Input Neuron for FP
FS_SingleNeuron.py				3 Neuron network of FS neurons
FYP_FS_CIFAR10.py				FS CIFAR10 converted network
FYP_FS_MNIST.py					FS MNIST converted network
FP Neuron Theoretical Implementation.ipynb	Notebook of FP neuron python code