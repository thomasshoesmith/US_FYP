#pragma once

// GeNN includes
#include "gennExport.h"

GENN_EXPORT unsigned int binomialInverseCDF(double cdf, unsigned int n, double p);