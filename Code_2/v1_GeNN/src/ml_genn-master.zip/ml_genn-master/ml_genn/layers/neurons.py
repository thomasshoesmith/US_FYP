from ml_genn.layers.base_neurons import BaseNeurons

class Neurons(BaseNeurons):
    pass
