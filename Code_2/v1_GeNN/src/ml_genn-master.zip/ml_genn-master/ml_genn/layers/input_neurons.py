from ml_genn.layers.base_neurons import BaseNeurons

class InputNeurons(BaseNeurons):
    pass
