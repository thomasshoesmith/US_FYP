from ml_genn.model import Model
from ml_genn.save_load import save_model, load_model
